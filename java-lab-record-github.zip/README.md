# Java Lab Record — GitHub Pages Website

A responsive student lab-record website inspired by the supplied reference screenshot, with a different dark violet/cyan theme, animated welcome screen, profile-photo area, and 11 week buttons.

## Included
- Animated intro screen with an **Enter Website** button.
- Student name: **V. Charan Teja**
- Roll number: **25EU02129**
- 11 week buttons.
- Each week has **Open PDF** and **Download PDF** actions.
- Responsive layout for mobile and desktop.
- Reduced-motion accessibility support.

## Before publishing

### 1. Add your profile photo
Copy your own photo into the `assets` folder and name it exactly:

`profile.jpg`

The image should be a JPG. If you use a PNG, name it `profile.png` and change `src="assets/profile.jpg"` in `index.html` to `src="assets/profile.png"`. The website shows a VC initials fallback if the photo is missing.

### 2. Add all 11 PDFs
Open the `pdfs` folder and add your actual PDF files with these exact names:

`week1.pdf`, `week2.pdf`, `week3.pdf`, `week4.pdf`, `week5.pdf`, `week6.pdf`, `week7.pdf`, `week8.pdf`, `week9.pdf`, `week10.pdf`, `week11.pdf`

Keep filenames lowercase and avoid spaces. The actual PDFs were not included in the request, so the project contains instructions rather than made-up lab records.

## Test on your computer
1. Extract the ZIP.
2. Add `assets/profile.jpg` and the 11 PDFs.
3. Double-click `index.html` to test in your browser.
4. Test at least two weeks and confirm both open and download actions work.

## Publish with GitHub Pages (step by step)

1. Sign in to [GitHub](https://github.com/).
2. Click **+** (top-right) → **New repository**.
3. Repository name: `java-lab-record`. Choose **Public** (simple option for GitHub Pages), then click **Create repository**.
4. On the repository page, click **Add file** → **Upload files**.
5. Upload `index.html`, `style.css`, `script.js`, `README.md`, the `assets` folder (with `profile.jpg` inside), and the `pdfs` folder (with all 11 PDFs inside). You can upload the project files together after extracting the ZIP on your computer. Make sure `index.html` is at the repository root—not inside another nested project folder.
6. Enter a commit message such as `Add Java Lab Record website`, then click **Commit changes**.
7. Open repository **Settings** → **Pages**.
8. Under **Build and deployment**, choose **Deploy from a branch**.
9. Select branch **main** and folder **/(root)**, then click **Save**.
10. Wait a few minutes and refresh the Pages section. GitHub will show your published URL, usually `https://YOUR-USERNAME.github.io/java-lab-record/`.
11. Open that URL and test Week 1 and Week 11. Check both opening and downloading.

## If you see a 404 error
- Check spelling and capitalization: `pdfs/week1.pdf` is different from `PDFs/Week1.pdf` on GitHub Pages.
- Confirm the PDFs were committed to the repository.
- Confirm `index.html` is at the root of the repository.
- If the site was just published, wait a few minutes and refresh.
- If a PDF opens but does not download, the browser may display it in a tab; use the page's download icon. The Download PDF link also asks the browser to download it.

## Project structure

```text
java-lab-record/
├── index.html
├── style.css
├── script.js
├── README.md
├── assets/
│   └── profile.jpg          # add your photo
└── pdfs/
    ├── week1.pdf            # add your PDF
    ├── week2.pdf
    ├── ...
    └── week11.pdf
```

## Important notes
- The site cannot display PDFs that have not been uploaded. Add all 11 files before publishing.
- A browser or GitHub Pages may display PDFs in a new tab when opening. The separate download link requests a download.
- The intro animation uses CSS and JavaScript; no framework or build tools are required.
